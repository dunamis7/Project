package console;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Facult extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Facult frame = new Facult();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Facult() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 1200, 700);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmBack = new JMenuItem("Back");
		mntmBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomeFrame frame = new WelcomeFrame();
				frame.setVisible(true);
				dispose();
			}
		});
		mnFile.add(mntmBack);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);

		JPanel panelfoe = new JPanel();
		panelfoe.setBackground(new Color(255, 255, 240));
		
		panelfoe.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0), 2, true), "FACULTY OF ENGINEERING", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JComboBox foe = new JComboBox();
		foe.setForeground(new Color(50, 205, 50));
		foe.setFont(new Font("Algerian", Font.BOLD, 24));
		foe.setModel(new DefaultComboBoxModel(new String[] {"SELECT YOUR DEPARTMENT", "COMPUTER SCIENCE AND ENGINEERING",
				"ELECTRICAL ENGINEERING", "MATHEMATICS", "MECHANICAL ENGINEERING", "RENEWABLE ENGINEERING"}));
		
		JRadioButton foey1 = new JRadioButton("Year 1");
		foey1.setForeground(new Color(50, 205, 50));
		foey1.setFont(new Font("Algerian", Font.PLAIN, 15));
		
		JRadioButton foey2 = new JRadioButton("Year 2");
		foey2.setFont(new Font("Algerian", Font.PLAIN, 15));
		foey2.setForeground(new Color(50, 205, 50));
		
		JRadioButton foey3 = new JRadioButton("Year 3");
		foey3.setFont(new Font("Algerian", Font.PLAIN, 15));
		foey3.setForeground(new Color(50, 205, 50));
		
		JRadioButton foey4 = new JRadioButton("Year 4");
		foey4.setFont(new Font("Algerian", Font.PLAIN, 15));
		foey4.setForeground(new Color(50, 205, 50));
		
		JPanel panelfmrt = new JPanel();
		panelfmrt.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0), 2, true), "FACULTY OF MINERAL RESOURCES AND TECHNOLOGY", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JComboBox fmrt = new JComboBox();
		fmrt.setForeground(new Color(50, 205, 50));
		fmrt.setFont(new Font("Algerian", Font.BOLD, 24));
		fmrt.setModel(new DefaultComboBoxModel(new String[] {"SELECT YOUR DEPARTMENT", "ENVIRONMENTAL AND SAFETY ENGINEERING", "GEOLOGICAL  ENGINEERING", "GEOMATIC  ENGINEERING", "MINERAL  ENGINEERING", "MINING  ENGINEERING", "PETROLEUM  ENGINEERING"}));
		
		JRadioButton fmrty4 = new JRadioButton("Year 4");
		fmrty4.setFont(new Font("Algerian", Font.PLAIN, 15));
		fmrty4.setForeground(new Color(50, 205, 50));
		
		JRadioButton fmrty1 = new JRadioButton("Year 1");
		fmrty1.setFont(new Font("Algerian", Font.PLAIN, 15));
		fmrty1.setForeground(new Color(50, 205, 50));
		
		JRadioButton fmrty2 = new JRadioButton("Year 2");
		fmrty2.setFont(new Font("Algerian", Font.PLAIN, 15));
		fmrty2.setForeground(new Color(50, 205, 50));
		
		JRadioButton fmrty3 = new JRadioButton("Year 3");
		fmrty3.setFont(new Font("Algerian", Font.PLAIN, 15));
		fmrty3.setForeground(new Color(50, 205, 50));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(panelfoe, GroupLayout.DEFAULT_SIZE, 557, Short.MAX_VALUE)
					.addGap(39)
					.addComponent(panelfmrt, GroupLayout.DEFAULT_SIZE, 567, Short.MAX_VALUE)
					.addGap(5))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(6)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(panelfmrt, GroupLayout.DEFAULT_SIZE, 639, Short.MAX_VALUE)
						.addComponent(panelfoe, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(6))
		);
		
		
		panelfoe.setOpaque(false);
		
		JButton foebtn = new JButton("SUBMIT");
		foebtn.setForeground(new Color(50, 205, 50));
		
		foebtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		GroupLayout gl_panelfoe = new GroupLayout(panelfoe);
		gl_panelfoe.setHorizontalGroup(
			gl_panelfoe.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelfoe.createSequentialGroup()
					.addGap(43)
					.addComponent(foey1, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(39)
					.addComponent(foey2, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(47)
					.addComponent(foey3, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addComponent(foey4, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(44))
				.addGroup(gl_panelfoe.createSequentialGroup()
					.addContainerGap(346, Short.MAX_VALUE)
					.addComponent(foebtn, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
					.addGap(4))
				.addGroup(gl_panelfoe.createSequentialGroup()
					.addGap(57)
					.addComponent(foe, GroupLayout.PREFERRED_SIZE, 442, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(44, Short.MAX_VALUE))
		);
		gl_panelfoe.setVerticalGroup(
			gl_panelfoe.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelfoe.createSequentialGroup()
					.addGap(51)
					.addComponent(foe, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 249, Short.MAX_VALUE)
					.addGroup(gl_panelfoe.createParallelGroup(Alignment.LEADING, false)
						.addComponent(foey1, GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
						.addComponent(foey2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(foey3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(foey4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(150)
					.addComponent(foebtn, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(5))
		);
		panelfoe.setLayout(gl_panelfoe);
		panelfmrt.setOpaque(false);
		
		JButton fmrtbtn = new JButton("Submit");
		fmrtbtn.setForeground(new Color(50, 205, 50));
		fmrtbtn.setFont(new Font("Tahoma", Font.BOLD, 13));
		GroupLayout gl_panelfmrt = new GroupLayout(panelfmrt);
		gl_panelfmrt.setHorizontalGroup(
			gl_panelfmrt.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelfmrt.createSequentialGroup()
					.addGap(70)
					.addComponent(fmrty1, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(39)
					.addComponent(fmrty2, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(47)
					.addComponent(fmrty3, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addComponent(fmrty4, GroupLayout.PREFERRED_SIZE, 82, GroupLayout.PREFERRED_SIZE)
					.addGap(27))
				.addGroup(gl_panelfmrt.createSequentialGroup()
					.addContainerGap(356, Short.MAX_VALUE)
					.addComponent(fmrtbtn, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
					.addGap(4))
				.addGroup(gl_panelfmrt.createSequentialGroup()
					.addGap(70)
					.addComponent(fmrt, GroupLayout.PREFERRED_SIZE, 422, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(61, Short.MAX_VALUE))
		);
		gl_panelfmrt.setVerticalGroup(
			gl_panelfmrt.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelfmrt.createSequentialGroup()
					.addGap(50)
					.addComponent(fmrt, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
					.addGap(252)
					.addGroup(gl_panelfmrt.createParallelGroup(Alignment.LEADING, false)
						.addComponent(fmrty1, GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
						.addComponent(fmrty2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(fmrty3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(fmrty4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addPreferredGap(ComponentPlacement.RELATED, 150, Short.MAX_VALUE)
					.addComponent(fmrtbtn, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(5))
		);
		panelfmrt.setLayout(gl_panelfmrt);
		
		
		
		
		panelfoe.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
		//	panelfmrt.setEnabled(false);
			fmrt.setEnabled(false);
			fmrty1.setEnabled(false);
			fmrty2.setEnabled(false);
			fmrty3.setEnabled(false);
			fmrty4.setEnabled(false);
//			fmrtbtn.setEnabled(false);
//			foebtn.setEnabled(true);
			
			}
		});
		
		
		panelfoe.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				
		//	panelfmrt.setEnabled(true);
			fmrt.setEnabled(true);
			fmrty1.setEnabled(true);
			fmrty2.setEnabled(true);
			fmrty3.setEnabled(true);
			fmrty4.setEnabled(true);
			//foebtn.setEnabled(false);
			
			}
		});
		
		
		
		
		
		
		
		panelfmrt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
			//panelfoe.setEnabled(false);
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
//				fmrtbtn.setEnabled(true);
//				foebtn.setEnabled(false);
			
			}
		});
		
		
		panelfmrt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				
		//	panelfmrt.setEnabled(true);
				foe.setEnabled(true);
				foey1.setEnabled(true);
				foey2.setEnabled(true);
				foey3.setEnabled(true);
				foey4.setEnabled(true);
				//foebtn.setEnabled(true);
			
			}
		});
		
		
		
		
		//FOE mouse hover
		foe.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				fmrt.setEnabled(false);
				fmrty1.setEnabled(false);
				fmrty2.setEnabled(false);
				fmrty3.setEnabled(false);
				fmrty4.setEnabled(false);
				//fmrtbtn.setEnabled(false);
				
			}
		});
		
		
		
		foey1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				fmrt.setEnabled(false);
				fmrty1.setEnabled(false);
				fmrty2.setEnabled(false);
				fmrty3.setEnabled(false);
				fmrty4.setEnabled(false);
//				fmrtbtn.setEnabled(false);
//				foebtn.setEnabled(true);
			}
		});
		
		
		
		foey2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				fmrt.setEnabled(false);
				fmrty1.setEnabled(false);
				fmrty2.setEnabled(false);
				fmrty3.setEnabled(false);
				fmrty4.setEnabled(false);
//				fmrtbtn.setEnabled(false);
//				foebtn.setEnabled(true);
				
			}
		});
		
		
		foey3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				fmrt.setEnabled(false);
				fmrty1.setEnabled(false);
				fmrty2.setEnabled(false);
				fmrty3.setEnabled(false);
				fmrty4.setEnabled(false);
//				fmrtbtn.setEnabled(false);
//				foebtn.setEnabled(true);
				
			}
		});
		
		
		foey4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				fmrt.setEnabled(false);
				fmrty1.setEnabled(false);
				fmrty2.setEnabled(false);
				fmrty3.setEnabled(false);
				fmrty4.setEnabled(false);
//				fmrtbtn.setEnabled(false);
//				foebtn.setEnabled(true);
				
			}
		});
		
		
		
		
		//FMRT mouse hover
		
		fmrt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
				//foebtn.setEnabled(false);
				
			}
		});
		
		
		
		fmrty1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
//				foebtn.setEnabled(false);
//				fmrtbtn.setEnabled(true);
				
			}
		});
		
		
		
		fmrty2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
//				foebtn.setEnabled(false);
//				fmrtbtn.setEnabled(true);
				
			}
		});
		
		
		
		fmrty3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
//				foebtn.setEnabled(false);
//				fmrtbtn.setEnabled(true);
				
			}
		});
		
		
		fmrty4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				
				foe.setEnabled(false);
				foey1.setEnabled(false);
				foey2.setEnabled(false);
				foey3.setEnabled(false);
				foey4.setEnabled(false);
//				foebtn.setEnabled(false);
//				fmrtbtn.setEnabled(true);
				
			}
		});
		
		
		
		//FOE event handler
		
		foe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foe.getSelectedIndex()>0) {
					fmrt.setSelectedIndex(0);
					foebtn.setEnabled(true);
					fmrtbtn.setEnabled(false);
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					fmrty1.setSelected(false);
					
				}
				
				
				
				
				
				
				
			}
		});
		
		//FMRT event handler
		
		fmrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrt.getSelectedIndex()>0) {
					foe.setSelectedIndex(0);
					foebtn.setEnabled(false);
					fmrtbtn.setEnabled(true);
					
					foey1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
				}
				
			}
		});
		
		
		
		fmrty1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrty1.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					foey1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					foe.setSelectedIndex(0);
					foebtn.setEnabled(false);
					fmrtbtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		fmrty2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrty2.isSelected()) {
					
					fmrty1.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					foey1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					foe.setSelectedIndex(0);
					foebtn.setEnabled(false);
					fmrtbtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		fmrty3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrty3.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty1.setSelected(false);
					fmrty4.setSelected(false);
					foey1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					foe.setSelectedIndex(0);
					foebtn.setEnabled(false);
					fmrtbtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		fmrty4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrty4.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty1.setSelected(false);
					foey1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					foe.setSelectedIndex(0);
					foebtn.setEnabled(false);
					fmrtbtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		foey1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foey1.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					fmrty1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					fmrt.setSelectedIndex(0);
					fmrtbtn.setEnabled(false);
					foebtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		
		
		
		foey2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foey2.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					fmrty1.setSelected(false);
					foey1.setSelected(false);
					foey3.setSelected(false);
					foey4.setSelected(false);
					fmrt.setSelectedIndex(0);
					fmrtbtn.setEnabled(false);
					foebtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		
		
		foey3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foey3.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					fmrty1.setSelected(false);
					foey2.setSelected(false);
					foey1.setSelected(false);
					foey4.setSelected(false);
					fmrt.setSelectedIndex(0);
					fmrtbtn.setEnabled(false);
					foebtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		
		foey4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foey4.isSelected()) {
					
					fmrty2.setSelected(false);
					fmrty3.setSelected(false);
					fmrty4.setSelected(false);
					fmrty1.setSelected(false);
					foey2.setSelected(false);
					foey3.setSelected(false);
					foey1.setSelected(false);
					fmrt.setSelectedIndex(0);
					fmrtbtn.setEnabled(false);
					foebtn.setEnabled(true);
					
					
				}
				
			}
		});
		
		
		
		
		
		
		foebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(foe.getSelectedIndex()==1 ) {
					JOptionPane.showMessageDialog(null, " You have selected COMPUTER SCIENCE AND ENGINEERING" );
					
					if(foey1.isSelected()) {
						CE__1 frame = new CE__1();
						frame.setVisible(true);
						dispose();
					}
					
					if(foey2.isSelected()) {
						CE__2 frame = new CE__2();
						frame.setVisible(true);
						dispose();
					}
					
				}
				if(foe.getSelectedIndex()==2 ) {
					JOptionPane.showMessageDialog(null, " You have selected ELECTRICAL ENGINEERING" );
				}
				if(foe.getSelectedIndex()==3 ) {
					JOptionPane.showMessageDialog(null, " You have selected MATHEMATICS");
				}
				if(foe.getSelectedIndex()==4 ) {
					JOptionPane.showMessageDialog(null, " You have selected MECHANICAL ENGINEERING" );
				}
				if(foe.getSelectedIndex()==5 ) {
					JOptionPane.showMessageDialog(null, " You have selected RENEWABLE ENGINEERING" );
				}
				
				
				
				
			}
		});
		
		
		
		
		
		
		
		
		
		
		contentPane.setLayout(gl_contentPane);
	}

	private static void setExtendedState(JPanel contentPane2) {
		// TODO Auto-generated method stub
		
	}
}
