package console;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Fac extends JFrame {

	private JPanel contentPane;
	private JPanel frames;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fac frame = new Fac();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Fac() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
	JLabel lblNewLabel = new JLabel("New label");
	lblNewLabel.setIcon(new ImageIcon(Fac.class.getResource("/console/ray-hennessy-118048-unsplash.jpg")));
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 700);
		frames = new JPanel();
		frames.setBackground(new Color(102, 204, 255));
		frames.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(frames);
		setExtendedState(MAXIMIZED_BOTH);
		
		
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		JComboBox fmrt = new JComboBox();
		JComboBox foe = new JComboBox();
		//foe.setEnabled(false);
		foe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(foe.isEnabled()) {
					fmrt.setEnabled(false);
				}
				
				
				if(foe.getSelectedItem()=="SELECT YOUR DEPARTMENT") {
					
					fmrt.setEnabled(true);
				}
				
//				else {
//					fmrt.setEnabled(true);
//					foe.setEnabled(false);
//					
//				}
			}
		});
		foe.setFont(new Font("Tahoma", Font.BOLD, 18));
		foe.setModel(new DefaultComboBoxModel(new String[] {"SELECT YOUR DEPARTMENT", "COMPUTER SCIENCE AND ENGINEERING", "ELECTRICAL ENGINEERING", "MATHEMATICS", "MECHANICAL ENGINEERING", "RENEWABLE ENGINEERING"}));
		
		//JComboBox fmrt = new JComboBox();
		
		
		
		fmrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(fmrt.isEnabled()) {
					foe.setEnabled(false);
				}
				
				
				if (fmrt.getSelectedItem()=="SELECT YOUR DEPARTMENT") {
					
					foe.setEnabled(true);
					
				}
			}
		});
		fmrt.setModel(new DefaultComboBoxModel(new String[] {"SELECT YOUR DEPARTMENT","ENVIRONMENTAL AND SAFETY ENGINEERING", "GEOLOGICAL  ENGINEERING", "GEOMATIC  ENGINEERING", "MINERAL  ENGINEERING", "MINING  ENGINEERING", "PETROLEUM  ENGINEERING"}));
		fmrt.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		
		
		
		
		
		
		JRadioButton radioYear4 = new JRadioButton("YEAR FOUR(4)");
		JRadioButton radioYear3 = new JRadioButton("YEAR THREE(3)");
		JRadioButton radioYear2 = new JRadioButton("YEAR TWO(2)");
		JRadioButton radioYear1 = new JRadioButton("YEAR ONE(1)");
		radioYear1.setMnemonic('1');
		radioYear1.setOpaque(false);
		radioYear1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(radioYear1.isSelected()) {
				
					radioYear2.setEnabled(false);
					radioYear3.setEnabled(false);
					radioYear4.setEnabled(false);			
					
				}
				else {
					
					radioYear4.setEnabled(true);
					radioYear2.setEnabled(true);
					radioYear3.setEnabled(true);
					
				}
				
				
				
				
				
			}
		});
		radioYear1.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		//JRadioButton radioYear2 = new JRadioButton("YEAR TWO(2)");
		radioYear2.setFont(new Font("Tahoma", Font.BOLD, 20));
		radioYear2.setOpaque(false);
		radioYear2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(radioYear2.isSelected()) {
				
					radioYear1.setEnabled(false);
					radioYear3.setEnabled(false);
					radioYear4.setEnabled(false);			
					
				}
				
				else {
					
					radioYear1.setEnabled(true);
					radioYear4.setEnabled(true);
					radioYear3.setEnabled(true);
					
				}
				
				
			}
		});
		
		//JRadioButton radioYear3 = new JRadioButton("YEAR THREE(3)");
		radioYear3.setFont(new Font("Tahoma", Font.BOLD, 20));
		radioYear3.setOpaque(false);
		radioYear3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(radioYear3.isSelected()) {
				
					radioYear1.setEnabled(false);
					radioYear2.setEnabled(false);
					radioYear4.setEnabled(false);			
					
				}
				else {
					
					radioYear1.setEnabled(true);
					radioYear2.setEnabled(true);
					radioYear4.setEnabled(true);
					
				}
				
				
			}
		});
		
		//JRadioButton radioYear4 = new JRadioButton("YEAR FOUR(4)");
		radioYear4.setFont(new Font("Tahoma", Font.BOLD, 20));
		radioYear4.setOpaque(false);
		radioYear4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(radioYear4.isSelected()) {
				
					radioYear1.setEnabled(false);
					radioYear2.setEnabled(false);
					radioYear3.setEnabled(false);			
					
				}
				else {
					
					radioYear1.setEnabled(true);
					radioYear2.setEnabled(true);
					radioYear3.setEnabled(true);
					
				}
				
				
			}
		});
		
		//int a = foe.getSelectedIndex();
		
		int b = fmrt.getSelectedIndex();
		
		 //boolean b = radioYear1.isSelected();
		
		
		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if (foe.getSelectedItem()=="COMPUTER SCIENCE AND ENGINEERING" && radioYear1.isSelected()) {
					CE__1 frame = new CE__1();
				frame.setVisible(true);
				dispose();
					
				}
				
				
				if (foe.getSelectedItem()=="COMPUTER SCIENCE AND ENGINEERING" && radioYear2.isSelected()) {
					CE__2 frame = new CE__2();
				frame.setVisible(true);
				dispose();
					
				}
				
				if (fmrt.getSelectedItem()=="ENVIRONMENTAL AND SAFETY ENGINEERING" && radioYear1.isSelected()) {
					
					EE_1 frame = new EE_1();
					frame.setVisible(true);
					dispose();
					
				}
				
//				if(foe.getSelectedIndex() == 0 && radioYear1.isSelected()) {
//					
//					CE__1 frame = new CE__1();
//					frame.setVisible(true);
//					dispose();
//					
//				}
			}
		});
		btnEnter.setFont(new Font("Tahoma", Font.BOLD, 20));
		GroupLayout gl_frames = new GroupLayout(frames);
		gl_frames.setHorizontalGroup(
			gl_frames.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_frames.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_frames.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnEnter, GroupLayout.PREFERRED_SIZE, 217, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_frames.createSequentialGroup()
							.addGroup(gl_frames.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_frames.createSequentialGroup()
									.addComponent(radioYear1, GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
									.addGap(75)
									.addComponent(radioYear2, GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
								.addComponent(foe, 0, 502, Short.MAX_VALUE))
							.addGroup(gl_frames.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_frames.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(separator, GroupLayout.PREFERRED_SIZE, 13, GroupLayout.PREFERRED_SIZE)
									.addGap(92)
									.addComponent(fmrt, GroupLayout.PREFERRED_SIZE, 543, GroupLayout.PREFERRED_SIZE)
									.addContainerGap())
								.addGroup(gl_frames.createSequentialGroup()
									.addGap(145)
									.addComponent(radioYear3)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(radioYear4)
									.addGap(25))))))
		);
		gl_frames.setVerticalGroup(
			gl_frames.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_frames.createSequentialGroup()
					.addGap(117)
					.addGroup(gl_frames.createParallelGroup(Alignment.LEADING)
						.addComponent(separator, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_frames.createSequentialGroup()
							.addGroup(gl_frames.createParallelGroup(Alignment.LEADING)
								.addComponent(fmrt, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
								.addComponent(foe, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE))
							.addGap(227)
							.addGroup(gl_frames.createParallelGroup(Alignment.BASELINE)
								.addComponent(radioYear1, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
								.addComponent(radioYear2, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
								.addComponent(radioYear4, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
								.addComponent(radioYear3, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 134, Short.MAX_VALUE)
							.addComponent(btnEnter, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		frames.setLayout(gl_frames);
	}
}