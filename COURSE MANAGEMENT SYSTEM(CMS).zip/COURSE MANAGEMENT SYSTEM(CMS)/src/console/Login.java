package console;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textUsername;
	private JPasswordField textPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("STYRENE");
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\Softwares\\ps\\T8ZRyGbr_400x400.jpg"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(470, 150, 494, 301);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(50, 205, 50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textUsername = new JTextField();
		textUsername.setFont(new Font("Arial", Font.PLAIN, 15));
		textUsername.setForeground(new Color(50, 205, 50));
		textUsername.setBounds(178, 64, 179, 25);
		contentPane.add(textUsername);
		textUsername.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Algerian", Font.PLAIN, 15));
		lblUsername.setForeground(new Color(50, 205, 50));
		lblUsername.setBounds(80, 54, 98, 45);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Algerian", Font.PLAIN, 15));
		lblPassword.setForeground(new Color(50, 205, 50));
		lblPassword.setBounds(80, 110, 87, 31);
		contentPane.add(lblPassword);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				String actualUserName = "Styrene";
				String actualPassword = "1234";
						
				String username = textUsername.getText();
				String password = textPassword.getText();
				
				if(username.equals(actualUserName) && password.equals(actualPassword)) {
					JOptionPane.showMessageDialog(contentPane,"You've logged in successfully" + username);
					WelcomeFrame frame = new WelcomeFrame();
					frame.setVisible(true);
					contentPane.setVisible(false);
				}
				else if(username.equals(actualUserName) || password.equals("")){
					JOptionPane.showMessageDialog(contentPane,"Sorry, Please Enter Password" );
				}
				else if(username.equals("") || password.equals(actualPassword)){
					JOptionPane.showMessageDialog(contentPane,"Sorry, Please Enter Username" );
				}
				else {
					JOptionPane.showMessageDialog(contentPane,"Incorrect Username or Password. Try again" );
					textUsername.setText("");
					textPassword.setText("");
				}
				
			}
		});
		btnLogin.setFont(new Font("Algerian", Font.PLAIN, 16));
		btnLogin.setForeground(new Color(50, 205, 50));
		btnLogin.setBounds(213, 207, 98, 37);
		contentPane.add(btnLogin);
		
		textPassword = new JPasswordField();
		textPassword.setFont(new Font("Arial", Font.PLAIN, 15));
		textPassword.setForeground(new Color(50, 205, 50));
		textPassword.setBounds(178, 112, 179, 26);
		contentPane.add(textPassword);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("D:\\Softwares\\ps\\umatTojava.jpg"));
		lblNewLabel.setBounds(-373, -69, 922, 462);
		contentPane.add(lblNewLabel);
	}
}
