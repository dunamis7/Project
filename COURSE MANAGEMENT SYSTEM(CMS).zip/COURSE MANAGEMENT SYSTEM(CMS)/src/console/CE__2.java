package console;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class CE__2 extends JFrame {

	private JPanel contentPane;
	
	private JTable table;
	private final JTable table_1 = new JTable();
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CE__2 frame = new CE__2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CE__2() {
		setResizable(false);
		setTitle("CMS-COMPUTER SCIENCE AND ENGINEERING TWO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 750);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		table_1.setForeground(new Color(50, 205, 50));
		
		table_1.setFont(new Font("Algerian", Font.BOLD, 15));
		table_1.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		table_1.setRowHeight(30);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{"Course Code", "Course Name", "Lecturer", "Credit Hour", "Materials"},
				{"260", "Literature", "Mrs Abbey", new Integer(1), null},
				{"265", "Discrete Mathematics", "Dr. Danso Addo", new Integer(3), null},
				{"266", "Differential Equations", "Dr. Boye", new Integer(3), null},
				{"268", "Micropprocessors and Controllers", "Mr. Kwantwi", new Integer(3), null},
				{"270", "Web Programming", "Mr. Aryeh", new Integer(2), null},
				{"272", "Programming with C++", "Mr. Agangiba", new Integer(2), null},
				{"277", "Database Systems", "Mr. Agangiba", new Integer(2), null},
				{"280", "Computer Graphics", "Mr. Aryeh", new Integer(2), null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "Materials"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_1.getColumnModel().getColumn(0).setPreferredWidth(85);
		table_1.getColumnModel().getColumn(1).setPreferredWidth(96);
		table_1.getColumnModel().getColumn(2).setPreferredWidth(85);
		table_1.getColumnModel().getColumn(3).setPreferredWidth(85);
		table_1.getColumnModel().getColumn(4).setPreferredWidth(85);
		
//		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
//		dtcr.setHorizontalTextPosition(DefaultTableCellRenderer.CENTER);
//		
		
		
		DefaultTableCellRenderer stringRenderer = (DefaultTableCellRenderer)
			     table_1.getDefaultRenderer(String.class);
				 table_1.getDefaultRenderer(Integer.class);
			stringRenderer.setHorizontalAlignment(SwingConstants.CENTER);
			
			
			
		table_2 = new JTable();
		table_2.setForeground(new Color(50, 205, 50));
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{"Course Code", "Course Name", "Lecturer", "Credit Hour", "Materials"},
				{"265", "Literature in English", "Mrs. Mills Abbey", "1", null},
				{"266", "Advanced Database Systems", "Mr. Felix Aryeh", "2", null},
				{"267", "Digital Electronics", "Dr. Nofong", "2", null},
				{"270", "Programming with Java", "Dr. Nofong", "2", null},
				{"272", "Embedded Systems", "Mr. Richard Annan", "3", null},
				{"277", "Software Engineering", "Mr. Richard Annan", "3", null},
				{"280", "Field Trip Report", "Mr. Agangiba", "1", null},
				{"282", "Mathematical Analysis", "Dr. Henry Otoo", "3", null},
				{"288", "Signals and Systems", "Professor Kayode", "3", null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column"
			}
		) {
			Class[] columnTypes = new Class[] {
					String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_2.getColumnModel().getColumn(0).setPreferredWidth(85);
		table_2.getColumnModel().getColumn(1).setPreferredWidth(85);
		table_2.getColumnModel().getColumn(2).setPreferredWidth(85);
		table_2.getColumnModel().getColumn(3).setPreferredWidth(85);
		table_2.setRowHeight(30);
		table_2.setFont(new Font("Algerian", Font.BOLD, 15));
		table_2.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		
		DefaultTableCellRenderer stringRenderer2 = (DefaultTableCellRenderer)
			     table_2.getDefaultRenderer(String.class);
				// table_2.getDefaultRenderer(Integer.class);
			stringRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		JLabel lblSemesterOne = new JLabel("SEMESTER ONE");
		lblSemesterOne.setEnabled(false);
		lblSemesterOne.setFont(new Font("Lucida Console", Font.BOLD, 11));
		lblSemesterOne.setHorizontalAlignment(SwingConstants.LEFT);
		
		JLabel lblSemesterTwo = new JLabel("SEMESTER TWO");
		lblSemesterTwo.setHorizontalAlignment(SwingConstants.LEFT);
		lblSemesterTwo.setFont(new Font("Lucida Console", Font.BOLD, 11));
		lblSemesterTwo.setEnabled(false);
		
		JButton button = new JButton("BACK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Facult frame = new Facult();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setFont(new Font("Tahoma", Font.BOLD, 20));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(table_2, GroupLayout.DEFAULT_SIZE, 1346, Short.MAX_VALUE)
						.addComponent(lblSemesterTwo, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblSemesterOne, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
						.addComponent(table_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 1356, Short.MAX_VALUE))
					.addGap(0))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(button, GroupLayout.PREFERRED_SIZE, 217, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(6)
					.addComponent(lblSemesterOne, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(table_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblSemesterTwo, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(table_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
					.addComponent(button, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE))
		);
		contentPane.setLayout(gl_contentPane);
		setExtendedState(MAXIMIZED_BOTH);		
	}
}
